package com.gupaoedu.p5;

import com.google.protobuf.Any;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
