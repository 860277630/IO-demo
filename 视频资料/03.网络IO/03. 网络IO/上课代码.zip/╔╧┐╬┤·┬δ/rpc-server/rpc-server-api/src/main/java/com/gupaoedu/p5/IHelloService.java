package com.gupaoedu.p5;

/**
 * 腾讯课堂搜索【咕泡学院】
 * 官网：www.gupaoedu.com
 * 风骚的Mic 老师
 * create-date: 2019/12/16-18:03
 */
public interface IHelloService {

    String sayHello(String name);

    String saveUser(User user);

    String queryUser();
}
